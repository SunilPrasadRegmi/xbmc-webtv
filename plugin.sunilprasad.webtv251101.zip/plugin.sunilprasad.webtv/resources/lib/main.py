import sys
import os
import json
import urllib.request
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# Direct URLs - minimal
API_URL = "https://ftatv-apis.sunilprasad.com.np/webtv-api"
WMS_URL = "https://ftatv-apis.sunilprasad.com.np/webtv-wms"

# addon & settings/localization helper
ADDON = xbmcaddon.Addon()
def lstr(id, fallback):
    try:
        return ADDON.getLocalizedString(int(id)) or fallback
    except Exception:
        return fallback

# artwork
ADDON_ROOT = os.path.normpath(ADDON.getAddonInfo('path'))
DEFAULT_ICON = os.path.join(ADDON_ROOT, "resources", "media", "icon.png")
DEFAULT_FANART = os.path.join(ADDON_ROOT, "resources", "media", "fanart.jpg")

# Common User-Agent
USER_AGENT = "Mozilla/5.0"

# Kodi plugin variables
HANDLE = None
PLUGIN_URL = None

def fetch_feed():
    try:
        req = urllib.request.Request(API_URL, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=6) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f"[plugin.sunilprasad.webtv] Feed fetch failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(lstr(30000, "WebTV"), lstr(30001, "Failed to load channels."))
        return {"feeds": []}

def build_url(**kwargs):
    return PLUGIN_URL + "?" + urllib.parse.urlencode(kwargs)

def list_categories(data):
    xbmcplugin.setContent(HANDLE, 'videos')
    for feed in data.get('feeds', []):
        li = xbmcgui.ListItem(label=feed.get('category_name', 'Unknown'))
        li.setArt({
            'thumb': feed.get('category_logo') or DEFAULT_ICON,
            'icon': feed.get('category_logo') or DEFAULT_ICON,
            'fanart': feed.get('category_fanart') or DEFAULT_FANART
        })
        li.setInfo('video', {'title': feed.get('category_name', ''), 'plot': feed.get('category_description', '')})
        url = build_url(action='list', category_slug=feed.get('category_slug', ''))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels(data, category_slug):
    category = next((f for f in data.get('feeds', []) if f.get('category_slug') == category_slug), None)
    if not category:
        xbmcgui.Dialog().ok(lstr(30000, "WebTV"), lstr(30004, "Category not found."))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setContent(HANDLE, 'videos')
    fanart = category.get('category_fanart') or DEFAULT_FANART

    for ch in category.get('channels', []):
        li = xbmcgui.ListItem(label=ch.get('channel_name') or 'Unnamed')
        li.setArt({'thumb': ch.get('channel_logo') or DEFAULT_ICON, 'icon': ch.get('channel_logo') or DEFAULT_ICON, 'fanart': fanart})
        li.setInfo('video', {'title': ch.get('channel_name', ''), 'plot': ch.get('channel_description', '')})
        li.setProperty('IsPlayable', 'true')
        
        url = build_url(action='play', stream_url=ch.get('channel_url', ''), title=ch.get('channel_name', ''))
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def fetch_wms():
    try:
        req = urllib.request.Request(WMS_URL, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=6) as resp:
            return json.loads(resp.read().decode('utf-8')).get('wmsAuthSign')
    except Exception as e:
        xbmc.log(f"[plugin.sunilprasad.webtv] WMS failed: {e}", xbmc.LOGERROR)
        return None

def play_stream(stream_url, title):
    if not stream_url:
        xbmcgui.Dialog().ok(lstr(30000, "WebTV"), lstr(30003, "No stream URL."))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    token = fetch_wms()
    if token:
        sep = '&' if '?' in stream_url else '?'
        stream_url = f"{stream_url}{sep}wmsAuthSign={token}"

    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'title': title})
    li.setProperty('IsPlayable', 'true')
    
    if '.m3u8' in stream_url:
        li.setProperty('inputstream.adaptive.stream_headers', f'User-Agent={USER_AGENT}')
        li.setProperty('inputstream.adaptive.manifest_headers', f'User-Agent={USER_AGENT}')
    
    li.setProperty('User-Agent', USER_AGENT)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def router(params):
    data = fetch_feed()
    action = params.get('action', [''])[0]

    if action == 'list':
        list_channels(data, params.get('category_slug', [''])[0])
    elif action == 'play':
        play_stream(params.get('stream_url', [''])[0], params.get('title', [''])[0])
    else:
        list_categories(data)

def run(argv):
    global HANDLE, PLUGIN_URL
    HANDLE = int(argv[1])
    PLUGIN_URL = argv[0]
    params = dict(urllib.parse.parse_qs(argv[2].lstrip('?')))
    router(params)